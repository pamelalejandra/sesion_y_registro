from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z._-]+\.[a-zA-Z]+$')
# PASSWORD_REGEX = re.compile(r'^[a-zA-Z]')

class Usuario:
    base_datos ='registro_sesion'
    
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.ocupacion = data['ocupacion']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    
    @classmethod
    def ingreso(cls,data):
        solicitud = """INSERT INTO usuarios (first_name, last_name, email, ocupacion, password, created_at, updated_at)
        VALUES (%(first_name)s, %(last_name)s, %(email)s, %(ocupacion)s, %(password)s, NOW(), NOW());"""
        return connectToMySQL(cls.base_datos).query_db(solicitud,data)
    
    @classmethod
    def get_all(cls):
        solicitud = "SELECT * FROM usuarios;"
        resultado = connectToMySQL(cls.base_datos).query_db(solicitud)
        lista_usuarios = []
        for b in resultado:
            lista_usuarios.append(cls(b))
        return lista_usuarios
    
    @classmethod
    def get_by_email(cls,data):
        solicitud = "SELECT * FROM usuarios WHERE email = %(email)s;"
        resultado = connectToMySQL(cls.base_datos).query_db(solicitud,data)
        if len(resultado) <1:
            return False
        return cls(resultado[0])
    
    @classmethod
    def get_one(cls,data):
        solicitud = "SELECT * FROM usuarios WHERE id =%(id)s;"
        resultado = connectToMySQL(cls.base_datos).query_db(solicitud,data)
        return cls(resultado[0])
    
    @staticmethod
    def validacion(usuario):
        correo_usuario = {'email':usuario['email']}
        is_valid = True
        if len(usuario['first_name']) < 2:
            flash("Tu nombre debe contener al menos 2 letras")
            is_valid = False
        if len(usuario['last_name']) < 2:
            flash("Tu apellido deber contener al menos 2 letras")
            is_valid = False
        if not EMAIL_REGEX.match(correo_usuario['email']):
            flash("Email no válido")
            is_valid = False
        elif Usuario.get_by_email(correo_usuario):
            flash("USUARIO YA CREADO")
            is_valid = False
        if len(usuario['password']) < 8:
            flash("Su contraseña debe contener al menos 8 caracteres")
        if (usuario['password']) != (usuario['repeticion']):
            flash("Las contraseñas no coinciden")
            is_valid = False
        return is_valid
