from flask import render_template, redirect, request, session, flash
from flask_app import app
from flask_bcrypt import Bcrypt
from flask_app.models.usuario_model import Usuario

bcrypt = Bcrypt(app)

@app.route('/')
def raiz():
    return render_template('index.html')
    
@app.route('/registrar_usuario', methods=['POST'])
def registrar():
    if not Usuario.validacion(request.form):
        return redirect('/')
    
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    print(pw_hash)
    data = {
        'first_name':request.form['first_name'],
        'last_name':request.form['last_name'],
        'email':request.form['email'],
        'ocupacion':request.form['ocupacion'],
        'password':pw_hash
    }
    user_id = Usuario.ingreso(data)
    session['user_id'] = user_id
    return redirect(f'/dashboard/{session["user_id"]}')
    
@app.route('/login', methods=['GET'])
def login2():
    return render_template('index.html')
    
@app.route('/login', methods=['POST'])
def login():
    data = { "email": request.form["log_email"] }
    user_base = Usuario.get_by_email(data)
    if not user_base:
        flash("Invalid Email or Password")
        return redirect('/')
    if not bcrypt.check_password_hash(user_base.password, request.form['password']):
        flash("Invalid Email/Password")
        return redirect('/')
    session['user_id'] = user_base.id
    return redirect(f'/dashboard/{session["user_id"]}')
    
@app.route('/dashboard/<int:id>')
def dashboard(id):
    if 'user_id' not in session:
        return redirect('/')
    data = {'id':session['user_id']}
    usuario = Usuario.get_one(data)
    todos_usuarios = Usuario.get_all()
    return render_template('index2.html', usuario=usuario, todos_usuarios=todos_usuarios)
    
@app.route('/clear_session')
def clear_session():
    session.clear()
    return redirect('/')