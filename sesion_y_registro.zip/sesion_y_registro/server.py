from flask_app.controllers import usuarios_controllers
from flask_app import app
app.secret_key="secreto"

if __name__=="__main__":
    app.run(debug=True)